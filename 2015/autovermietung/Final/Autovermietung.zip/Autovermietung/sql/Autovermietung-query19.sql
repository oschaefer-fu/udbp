-- Aufgabe 19
-- Zu welcher Kategorie gehört der Opel Astra?	
SELECT DISTINCT KName 
FROM Auto 
WHERE AModell = 'Opel Astra';
