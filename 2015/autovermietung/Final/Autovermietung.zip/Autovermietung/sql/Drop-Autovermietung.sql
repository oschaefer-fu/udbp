-- Versionsdatum:	9.6.2015
-- Autor: 			von D. Fröhlich, M. Möbius, R. Schönfeld
-- Thema: 			Miniwelt Autovermietung


DROP TABLE Station CASCADE;
DROP TABLE Auto CASCADE;
DROP TABLE Kategorie CASCADE; 
DROP TABLE Mieter CASCADE;
DROP TABLE Vertrag CASCADE;
DROP TABLE Zubehoer CASCADE; 
DROP TABLE gebucht CASCADE; 
