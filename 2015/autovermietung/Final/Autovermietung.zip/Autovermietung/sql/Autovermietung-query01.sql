-- Aufgabe 01 - Aufgaben sind zum kennenlernen der unterschiedlichen SQL Funktionen
-- Gib die Daten der Tabelle Auto aus.	
SELECT * 
FROM Auto; 2
