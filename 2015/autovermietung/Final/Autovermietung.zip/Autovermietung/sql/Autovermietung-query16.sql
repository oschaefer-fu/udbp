-- Aufgabe 16
-- Gib den durchschnittlichen Tagespreis über alle Kategorien an.	
SELECT avg (KTagespreis) 
FROM Kategorie;
