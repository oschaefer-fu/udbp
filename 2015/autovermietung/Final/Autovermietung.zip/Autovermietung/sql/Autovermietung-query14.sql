-- Aufgabe 14
-- Wie viele Autos gibt es mit 2 Sitzplätzen?	
SELECT count (*) 
FROM Auto 
WHERE ASitzplaetze = 2;
