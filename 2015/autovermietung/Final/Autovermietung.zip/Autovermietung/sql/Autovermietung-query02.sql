-- Aufgabe 02
-- Gib alle Auto mit Kennzeichen an, die 2 Sitzplätze haben.	
SELECT ANr,Amodell 
FROM Auto 
WHERE ASitzplaetze = 2;
