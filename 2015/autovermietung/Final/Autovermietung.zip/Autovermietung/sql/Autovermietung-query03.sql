-- Aufgabe 03
-- Gib alle Auto mit Kennzeichen an, die mehr als 4 Sitzplätze haben.	
SELECT ANr,AModell
FROM Auto 
WHERE ASitzplaetze > 4;
