-- Versionsdatum:	9.6.2015
-- Autor: 			von D. Fröhlich, M. Möbius, R. Schönfeld
-- Thema: 			Miniwelt Autovermietung

TRUNCATE TABLE Station;
TRUNCATE TABLE Auto;
TRUNCATE TABLE Kategorie; 
TRUNCATE TABLE Mieter;
TRUNCATE TABLE Vertrag;
TRUNCATE TABLE Zubehoer; 
TRUNCATE TABLE gebucht;
