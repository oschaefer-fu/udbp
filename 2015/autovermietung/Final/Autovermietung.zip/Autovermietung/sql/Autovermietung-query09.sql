-- Aufgabe 09
-- In welchen Kennzeichen kommt der Buchstabe F vor?	
SELECT ANr 
FROM Auto 
WHERE ANr LIKE '%F%';
