"Alle Schueler aus Kladow"
 snr | vorname |   name   | ortsteil |        mail        | klasse | eltok 
-----+---------+----------+----------+--------------------+--------+-------
   4 | Stefan  | Bussmann | Kladow   | SBussi@hotmail.com |      8 | t
   5 | Jana    | Dussel   | Kladow   | JD@haha.com        |      9 | t
(2 Zeilen)

"Die Namen aller Schueler der 9. Klasse"
  name  
--------
 Dussel
 Depp
 Grell
(3 Zeilen)

"Die Schueler der 8. Klasse mit Ortsteil"
 klasse |   name   | ortsteil 
--------+----------+----------
      8 | Aust     | Staaken
      8 | Bussmann | Kladow
      8 | Ebert    | Altstadt
      8 | Frei     | Gatow
(4 Zeilen)

"Namen und E-Mailadressen aller Tutoren in der Altstadt"
 name |      mail      
------+----------------
 Depp | ADepp@here.com
(1 Zeile)

"Namen und E-Mailadressen aller Tutoren mit ihren Fächern"
  name  |        mail         |   fname    | fnr 
--------+---------------------+------------+-----
 Aust   | faust@istdoch.net   | Mathematik |   1
 Dussel | JD@haha.com         | Deutsch    |   3
 Dussel | JD@haha.com         | Deutsch    |   4
 Depp   | ADepp@here.com      | Englisch   |   5
 Grell  | H.Grell@hotmail.com | Mathematik |   2
 Grell  | H.Grell@hotmail.com | NaWi       |   6
(6 Zeilen)

"Tutoren für Mathematik Stufe 7"
 snr | vorname | name  |  ortsteil  |        mail         | klasse | eltok | fnr 
-----+---------+-------+------------+---------------------+--------+-------+-----
   8 | Hans    | Grell | Hakenfelde | H.Grell@hotmail.com |      9 | t     |   2
(1 Zeile)

"Alle von Tutor Depp angebotenen Slots"
 name | tag | stunde | kw | schuljahr 
------+-----+--------+----+-----------
 Depp | Mon |      8 |  4 |      2015
 Depp | Die |      7 |  2 |      2015
 Depp | Don |      9 | 46 |      2014
(3 Zeilen)

"Namen und E-Mailadressen aller Tutoren die Slots in 2015 anbieten mit den entsprechenden Slots"
  name  |        mail         | tag | stunde | kw | schuljahr 
--------+---------------------+-----+--------+----+-----------
 Dussel | JD@haha.com         | Die |      7 |  2 |      2015
 Dussel | JD@haha.com         | Die |      7 |  2 |      2015
 Depp   | ADepp@here.com      | Die |      7 |  2 |      2015
 Depp   | ADepp@here.com      | Mon |      8 |  4 |      2015
 Aust   | faust@istdoch.net   | Don |      0 |  6 |      2015
 Grell  | H.Grell@hotmail.com | Mit |      9 |  7 |      2015
 Grell  | H.Grell@hotmail.com | Mit |      9 |  7 |      2015
 Grell  | H.Grell@hotmail.com | Mon |      7 | 10 |      2015
 Grell  | H.Grell@hotmail.com | Mon |      7 | 10 |      2015
(9 Zeilen)

"Namen und E-Mailadressen aller Tutoren die Slots in 2015 anbieten mit den entsprechenden Slots"
  name  |        mail         | tag | stunde | kw | schuljahr |   fname    | stufe 
--------+---------------------+-----+--------+----+-----------+------------+-------
 Dussel | JD@haha.com         | Die |      7 |  2 |      2015 | Deutsch    |     8
 Dussel | JD@haha.com         | Die |      7 |  2 |      2015 | Deutsch    |     7
 Depp   | ADepp@here.com      | Die |      7 |  2 |      2015 | Englisch   |     7
 Depp   | ADepp@here.com      | Mon |      8 |  4 |      2015 | Englisch   |     7
 Aust   | faust@istdoch.net   | Don |      0 |  6 |      2015 | Mathematik |     8
 Grell  | H.Grell@hotmail.com | Mit |      9 |  7 |      2015 | Mathematik |     7
 Grell  | H.Grell@hotmail.com | Mit |      9 |  7 |      2015 | NaWi       |     8
 Grell  | H.Grell@hotmail.com | Mon |      7 | 10 |      2015 | Mathematik |     7
 Grell  | H.Grell@hotmail.com | Mon |      7 | 10 |      2015 | NaWi       |     8
(9 Zeilen)

"Namen und E-Mailadressen aller Tutoren die Slots in 2015 anbieten mit den entsprechenden Slots"
  name  |        mail         | tag | stunde | kw | schuljahr 
--------+---------------------+-----+--------+----+-----------
 Dussel | JD@haha.com         | Die |      7 |  2 |      2015
 Depp   | ADepp@here.com      | Die |      7 |  2 |      2015
 Dussel | JD@haha.com         | Die |      7 |  2 |      2015
 Aust   | faust@istdoch.net   | Don |      0 |  6 |      2015
 Grell  | H.Grell@hotmail.com | Mit |      9 |  7 |      2015
 Grell  | H.Grell@hotmail.com | Mit |      9 |  7 |      2015
 Grell  | H.Grell@hotmail.com | Mon |      7 | 10 |      2015
 Depp   | ADepp@here.com      | Mon |      8 |  4 |      2015
 Grell  | H.Grell@hotmail.com | Mon |      7 | 10 |      2015
(9 Zeilen)

"Namen, Vornamen, Ortsteile aller Schüler, die keine Tutoren sind"
   name   | vorname |  ortsteil  
----------+---------+------------
 Bussmann | Stefan  | Kladow
 Ebert    | Jan     | Altstadt
 Berend   | Michael | Hakenfelde
 Ahrend   | Joschua | Staaken
 Frei     | Bianca  | Gatow
(5 Zeilen)

"Alle stattgefundenen Stunden"
 stdnr |   fname    
-------+------------
     0 | Mathematik
     2 | Deutsch
     3 | Mathematik
     4 | Englisch
     1 | Mathematik
(5 Zeilen)

"Kostenauflistung nach Schülernamen"
  sum  |  name  
-------+--------
 20.00 | Berend
(1 Zeile)

